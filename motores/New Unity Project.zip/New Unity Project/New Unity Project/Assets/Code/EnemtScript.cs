using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemtScript : MonoBehaviour
{
  public int health, damage;

  private void Start() {
    Presentation();
  }

  public void Presentation(){
    //print("My name is: " + name);
    Debug.Log("My name is: " + name);
  }

  private void Update() {
    
  }
}