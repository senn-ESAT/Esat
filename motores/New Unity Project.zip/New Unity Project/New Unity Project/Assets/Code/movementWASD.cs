using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movementWASD : MonoBehaviour
{
  // [SerializzedField] es para que un private sea visible
  // public Transform tr;              // posicion de cubo
  // Vector3 currentPosition;
  // public float deltaMovePerFrame;   // distancia movimiento cada frame
  // public float radiusOffset;        // area de seguridad para evitar pasarse de posicion

  // Start is called before the first frame update
  // void Start(){

  //}

  void Update(){
    // if (Input.GetKeyDown("space")){
    //     Debug.Log("space key was pressed");
    // }
    if (Input.GetKeyDown(KeyCode.Space)){
      Debug.Log("space key was pressed");
    }
  }
} 